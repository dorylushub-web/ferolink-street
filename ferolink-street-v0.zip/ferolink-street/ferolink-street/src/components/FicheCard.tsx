'use client'

import type { Prospect } from '@/lib/supabaseClient'
import { ACTOR_LABELS } from '@/lib/questionnaires'
import type { ActorType } from '@/lib/supabaseClient'
import { getScoreLabel, getFinalScore } from '@/lib/scoring'
import { saveLocalProspect, updateLocalProspect } from '@/lib/localStore'
import { pushProspectToSupabase } from '@/lib/sync'

interface Props {
  prospect: Prospect
  onUpdate?: (updated: Prospect) => void
}

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  nouveau:     { label: 'Nouveau',     color: 'text-blue-400' },
  contacte:    { label: 'Contacté',    color: 'text-yellow-400' },
  qualifie:    { label: 'Qualifié',    color: 'text-emerald-400' },
  prioritaire: { label: 'Prioritaire', color: 'text-orange-400' },
  test:        { label: 'En test',     color: 'text-purple-400' },
  converti:    { label: 'Converti',    color: 'text-green-300' },
  perdu:       { label: 'Perdu',       color: 'text-red-400' },
  archive:     { label: 'Archivé',     color: 'text-gray-500' },
}

// EN: Lead card / Prospect record card
// Sync status = État de synchronisation (cloud vs local)
// Score tier = Niveau de score / Lead quality

export default function FicheCard({ prospect, onUpdate }: Props) {
  const scoreInfo = getScoreLabel(prospect.score_final)
  const status = STATUS_LABELS[prospect.status] || STATUS_LABELS.nouveau

  const handleScoreEdit = () => {
    const current = prospect.score_manuel?.toString() ?? ''
    const input = window.prompt(
      `Score manuel pour ${prospect.full_name}\n(0–100, laisser vide = score auto)`,
      current
    )
    if (input === null) return // Annulé

    const trimmed = input.trim()
    const newManuel = trimmed === '' ? null : parseInt(trimmed, 10)

    if (newManuel !== null && (isNaN(newManuel) || newManuel < 0 || newManuel > 100)) {
      alert('Le score doit être entre 0 et 100')
      return
    }

    const newFinal = getFinalScore(prospect.score_auto, newManuel)
    const updated: Prospect = {
      ...prospect,
      score_manuel: newManuel,
      score_final: newFinal,
      is_synced: false,
    }

    saveLocalProspect(updated)

    // Tenter sync Supabase
    if (navigator.onLine) {
      pushProspectToSupabase(updated).then((res) => {
        if (res.success) {
          updateLocalProspect(updated.local_id, { is_synced: true })
        }
      })
    }

    onUpdate?.(updated)
  }

  return (
    <div className={`
      bg-anthracite-800 border rounded-2xl p-4 space-y-3 transition-all
      ${scoreInfo.isPriority
        ? 'border-brand-orange shadow-lg shadow-orange-500/10'
        : 'border-anthracite-600'
      }
    `}>
      {/* Bandeau PRIORITAIRE */}
      {scoreInfo.isPriority && (
        <div className="bg-brand-orange/20 border border-brand-orange/40 rounded-xl px-3 py-1.5 text-center">
          <span className="text-brand-orange font-bold text-sm tracking-wide">
            🔥 PRIORITAIRE — Appeler immédiatement
          </span>
        </div>
      )}

      {/* Header nom + sync */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="text-cream font-bold text-base truncate">
            {prospect.full_name}
          </div>
          <div className="text-gray-400 text-sm">
            📍 {prospect.city}
            {prospect.zone ? ` — ${prospect.zone}` : ''}
          </div>
        </div>
        <span className={`
          flex-shrink-0 text-xs px-2 py-0.5 rounded-full
          ${prospect.is_synced
            ? 'bg-emerald-900/50 text-emerald-400'
            : 'bg-orange-900/50 text-orange-400'
          }
        `}>
          {prospect.is_synced ? '☁ Cloud' : '📵 Local'}
        </span>
      </div>

      {/* Type + Statut */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs bg-forest-700 text-brand-gold px-2 py-1 rounded-lg">
          {ACTOR_LABELS[prospect.actor_type as ActorType] || prospect.actor_type}
        </span>
        <span className={`text-xs font-medium ${status.color}`}>
          ● {status.label}
        </span>
      </div>

      {/* Score */}
      <div className="flex items-center justify-between gap-2">
        <span className={`
          text-xs font-bold px-3 py-1.5 rounded-full
          ${scoreInfo.bg} ${scoreInfo.color}
        `}>
          {scoreInfo.emoji} {scoreInfo.label} — {prospect.score_final}/100
        </span>
        <div className="flex items-center gap-2">
          {prospect.score_manuel !== null && (
            <span className="text-xs text-brand-gold">✏ Manuel</span>
          )}
          <button
            onClick={handleScoreEdit}
            className="text-xs text-gray-400 hover:text-brand-gold underline transition-colors"
          >
            Modifier
          </button>
        </div>
      </div>

      {/* Action recommandée */}
      <div className="text-xs text-gray-500 italic">
        → {scoreInfo.action}
      </div>

      {/* Téléphone — bouton appel direct */}
      <a
        href={`tel:${prospect.phone}`}
        className="flex items-center gap-2 bg-brand-green/20 border border-brand-green/40 rounded-xl px-3 py-2.5 text-brand-light text-sm font-medium hover:bg-brand-green/30 transition-colors active:scale-98"
      >
        <span className="text-lg">📞</span>
        <span>{prospect.phone}</span>
        <span className="ml-auto text-xs text-brand-gold">Appeler</span>
      </a>

      {/* Notes */}
      {prospect.notes && (
        <div className="text-gray-500 text-xs italic border-t border-anthracite-700 pt-2">
          {prospect.notes}
        </div>
      )}
    </div>
  )
}
