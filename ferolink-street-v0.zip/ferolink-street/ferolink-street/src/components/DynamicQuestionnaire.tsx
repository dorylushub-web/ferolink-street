'use client'

import { QUESTIONNAIRES } from '@/lib/questionnaires'
import type { ActorType } from '@/lib/supabaseClient'

interface Props {
  actorType: ActorType
  answers: Record<string, string | number>
  onChange: (answers: Record<string, string | number>) => void
}

// EN: Dynamic survey form / Field questionnaire

export default function DynamicQuestionnaire({ actorType, answers, onChange }: Props) {
  const questions = QUESTIONNAIRES[actorType]

  const update = (questionId: string, value: string | number) =>
    onChange({ ...answers, [questionId]: value })

  return (
    <div className="space-y-6">
      <h2 className="text-cream font-bold text-xl">Questionnaire</h2>

      {questions.map((question, index) => (
        <div key={question.id} className="space-y-2">
          <label className="block text-gray-300 text-sm font-medium">
            <span className="text-brand-gold mr-1">{index + 1}.</span>
            {question.label}
            {question.required && <span className="text-brand-gold ml-1">*</span>}
          </label>

          {question.type === 'radio' && question.options && (
            <div className="space-y-2">
              {question.options.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => update(question.id, option.value)}
                  className={`
                    w-full text-left px-4 py-3 rounded-xl border transition-all duration-150 text-sm
                    ${answers[question.id] === option.value
                      ? 'border-brand-gold bg-forest-700 text-cream'
                      : 'border-anthracite-600 bg-anthracite-800 text-gray-300 hover:border-brand-green'
                    }
                  `}
                >
                  <span className="flex items-center gap-3">
                    <span className={`
                      w-4 h-4 rounded-full border-2 flex-shrink-0 transition-all
                      ${answers[question.id] === option.value
                        ? 'border-brand-gold bg-brand-gold'
                        : 'border-gray-500'
                      }
                    `} />
                    {option.label}
                  </span>
                </button>
              ))}
            </div>
          )}

          {question.type === 'text' && (
            <input
              type="text"
              value={(answers[question.id] as string) || ''}
              onChange={(e) => update(question.id, e.target.value)}
              className="w-full bg-anthracite-800 border border-anthracite-600 text-cream rounded-xl px-4 py-3 focus:outline-none focus:border-brand-gold placeholder-gray-500"
            />
          )}

          {question.type === 'number' && (
            <input
              type="number"
              value={(answers[question.id] as number) || ''}
              onChange={(e) => update(question.id, Number(e.target.value))}
              className="w-full bg-anthracite-800 border border-anthracite-600 text-cream rounded-xl px-4 py-3 focus:outline-none focus:border-brand-gold placeholder-gray-500"
            />
          )}
        </div>
      ))}
    </div>
  )
}
