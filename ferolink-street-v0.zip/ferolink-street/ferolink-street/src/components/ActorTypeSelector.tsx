'use client'

import { ACTOR_LABELS } from '@/lib/questionnaires'
import type { ActorType } from '@/lib/supabaseClient'

interface Props {
  selected: ActorType | null
  onSelect: (type: ActorType) => void
}

const ACTOR_DESCRIPTIONS: Record<ActorType, string> = {
  commercant:       'Vendeur, marchand, distributeur',
  producteur:       'Agriculteur, éleveur, pêcheur',
  transporteur:     'Chauffeur, propriétaire flotte',
  partenaire_local: 'ONG, mairie, coopérative',
  client_pro:       'Entreprise, industrie, grossiste',
}

// EN: Actor type = Supply chain stakeholder type
export default function ActorTypeSelector({ selected, onSelect }: Props) {
  const types = Object.keys(ACTOR_LABELS) as ActorType[]

  return (
    <div className="space-y-3">
      <h2 className="text-cream font-bold text-xl">Type d&apos;acteur</h2>
      <p className="text-gray-400 text-sm">Sélectionne le profil terrain</p>
      <div className="grid grid-cols-1 gap-3">
        {types.map((type) => {
          const [emoji, ...rest] = ACTOR_LABELS[type].split(' ')
          const label = rest.join(' ')
          return (
            <button
              key={type}
              onClick={() => onSelect(type)}
              className={`
                w-full text-left p-4 rounded-xl border-2 transition-all duration-150 active:scale-98
                ${selected === type
                  ? 'border-brand-gold bg-forest-700 shadow-lg shadow-yellow-500/10'
                  : 'border-anthracite-600 bg-anthracite-800 hover:border-brand-green'
                }
              `}
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{emoji}</span>
                <div className="flex-1">
                  <div className="text-cream font-semibold">{label}</div>
                  <div className="text-gray-400 text-sm">{ACTOR_DESCRIPTIONS[type]}</div>
                </div>
                {selected === type && (
                  <span className="text-brand-gold text-xl font-bold">✓</span>
                )}
              </div>
            </button>
          )
        })}
      </div>
    </div>
  )
}
