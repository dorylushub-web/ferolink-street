'use client'

import { ACTOR_LABELS } from '@/lib/questionnaires'
import type { ActorType } from '@/lib/supabaseClient'

export interface Filters {
  actorType: string
  city: string
  status: string
}

interface Props {
  filters: Filters
  onChange: (filters: Filters) => void
  cities: string[]
}

const selectClass =
  'flex-1 min-w-0 px-3 py-2.5 rounded-xl border border-anthracite-600 text-cream text-sm bg-anthracite-800 focus:outline-none focus:border-brand-gold min-h-[44px]'

// EN: Filter bar = Barre de filtres / Pipeline filter
export default function FilterBar({ filters, onChange, cities }: Props) {
  const update = (field: keyof Filters, value: string) =>
    onChange({ ...filters, [field]: value })

  const hasFilters = filters.actorType || filters.city || filters.status

  return (
    <div className="space-y-2">
      <div className="flex gap-2">
        <select
          value={filters.actorType}
          onChange={(e) => update('actorType', e.target.value)}
          className={selectClass}
        >
          <option value="">Tous types</option>
          {(Object.entries(ACTOR_LABELS) as [ActorType, string][]).map(([v, label]) => (
            <option key={v} value={v}>{label}</option>
          ))}
        </select>

        <select
          value={filters.status}
          onChange={(e) => update('status', e.target.value)}
          className={selectClass}
        >
          <option value="">Tous statuts</option>
          <option value="nouveau">Nouveau</option>
          <option value="contacte">Contacté</option>
          <option value="qualifie">Qualifié</option>
          <option value="prioritaire">🔥 Prioritaire</option>
          <option value="test">En test</option>
          <option value="converti">Converti</option>
          <option value="perdu">Perdu</option>
          <option value="archive">Archivé</option>
        </select>
      </div>

      {cities.length > 0 && (
        <select
          value={filters.city}
          onChange={(e) => update('city', e.target.value)}
          className={`${selectClass} w-full`}
        >
          <option value="">Toutes les villes</option>
          {cities.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      )}

      {hasFilters && (
        <button
          onClick={() => onChange({ actorType: '', city: '', status: '' })}
          className="text-sm text-brand-gold hover:text-yellow-300 underline transition-colors"
        >
          ✕ Effacer les filtres
        </button>
      )}
    </div>
  )
}
