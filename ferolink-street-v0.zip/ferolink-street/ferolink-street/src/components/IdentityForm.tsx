'use client'

export interface IdentityData {
  full_name: string
  phone: string
  city: string
  zone: string
  contact_channel: string
  referred_by: string
  payment_preference: string
  notes: string
}

export const defaultIdentity: IdentityData = {
  full_name: '',
  phone: '',
  city: '',
  zone: '',
  contact_channel: '',
  referred_by: '',
  payment_preference: '',
  notes: '',
}

interface Props {
  data: IdentityData
  onChange: (data: IdentityData) => void
}

// EN: Identity form / Contact intake form
// full_name = Nom complet | phone = Téléphone | city = Ville
// zone = Zone/Quartier | contact_channel = Canal de contact
// referred_by = Référent / Source | payment_preference = Mode de paiement préféré

export default function IdentityForm({ data, onChange }: Props) {
  const update = (field: keyof IdentityData, value: string) =>
    onChange({ ...data, [field]: value })

  const inputClass =
    'w-full bg-anthracite-800 border border-anthracite-600 text-cream rounded-xl px-4 py-3 text-base focus:outline-none focus:border-brand-gold placeholder-gray-500 min-h-[48px]'
  const labelClass = 'block text-gray-300 text-sm font-medium mb-1'
  const reqStar = <span className="text-brand-gold ml-0.5">*</span>

  return (
    <div className="space-y-4">
      <h2 className="text-cream font-bold text-xl">Identité</h2>

      <div>
        <label className={labelClass}>Nom complet {reqStar}</label>
        <input
          type="text"
          value={data.full_name}
          onChange={(e) => update('full_name', e.target.value)}
          placeholder="Ex: Moussa Diallo"
          className={inputClass}
          autoComplete="off"
        />
      </div>

      <div>
        <label className={labelClass}>Téléphone {reqStar}</label>
        <input
          type="tel"
          value={data.phone}
          onChange={(e) => update('phone', e.target.value)}
          placeholder="+221 77 123 45 67"
          className={inputClass}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className={labelClass}>Ville {reqStar}</label>
          <input
            type="text"
            value={data.city}
            onChange={(e) => update('city', e.target.value)}
            placeholder="Thiès, Kaolack…"
            className={inputClass}
          />
        </div>
        <div>
          <label className={labelClass}>Zone / Quartier</label>
          <input
            type="text"
            value={data.zone}
            onChange={(e) => update('zone', e.target.value)}
            placeholder="Marché central…"
            className={inputClass}
          />
        </div>
      </div>

      <div>
        <label className={labelClass}>Canal de contact</label>
        <select
          value={data.contact_channel}
          onChange={(e) => update('contact_channel', e.target.value)}
          className={inputClass}
        >
          <option value="">Sélectionner…</option>
          <option value="terrain">Terrain (direct)</option>
          <option value="telephone">Téléphone</option>
          <option value="whatsapp">WhatsApp</option>
          <option value="referral">Recommandation</option>
          <option value="reseaux">Réseaux sociaux</option>
          <option value="autre">Autre</option>
        </select>
      </div>

      <div>
        <label className={labelClass}>Référent / Source</label>
        <input
          type="text"
          value={data.referred_by}
          onChange={(e) => update('referred_by', e.target.value)}
          placeholder="Nom du référent ou source"
          className={inputClass}
        />
      </div>

      <div>
        <label className={labelClass}>Mode de paiement préféré</label>
        <select
          value={data.payment_preference}
          onChange={(e) => update('payment_preference', e.target.value)}
          className={inputClass}
        >
          <option value="">Sélectionner…</option>
          <option value="cash">Cash / Espèces</option>
          <option value="mobile_money">Mobile Money (Wave, Orange…)</option>
          <option value="virement">Virement bancaire</option>
          <option value="cheque">Chèque</option>
          <option value="credit">Crédit / Délai</option>
        </select>
      </div>

      <div>
        <label className={labelClass}>Notes terrain (optionnel)</label>
        <textarea
          value={data.notes}
          onChange={(e) => update('notes', e.target.value)}
          placeholder="Observations, contexte, remarques…"
          rows={3}
          className={`${inputClass} min-h-[80px] resize-none`}
        />
      </div>
    </div>
  )
}
