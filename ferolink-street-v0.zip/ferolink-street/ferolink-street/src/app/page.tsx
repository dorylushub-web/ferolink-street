'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import type { Prospect } from '@/lib/supabaseClient'
import { getLocalProspects, getUnsyncedProspects } from '@/lib/localStore'
import { syncAll, fetchAllFromSupabase } from '@/lib/sync'
import { ACTOR_LABELS } from '@/lib/questionnaires'
import type { ActorType } from '@/lib/supabaseClient'

export default function Dashboard() {
  const [prospects, setProspects] = useState<Prospect[]>([])
  const [unsynced, setUnsynced] = useState(0)
  const [syncing, setSyncing] = useState(false)
  const [syncMsg, setSyncMsg] = useState('')
  const [online, setOnline] = useState(true)

  useEffect(() => {
    if (typeof window === 'undefined') return
    setOnline(navigator.onLine)

    const handleOnline = () => { setOnline(true); doSync() }
    const handleOffline = () => setOnline(false)
    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)
    loadData()

    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function loadData() {
    const local = getLocalProspects()
    setProspects(local)
    setUnsynced(getUnsyncedProspects().length)

    if (navigator.onLine) {
      const remote = await fetchAllFromSupabase()
      if (remote.length > 0) {
        setProspects(remote)
        setUnsynced(getUnsyncedProspects().length)
      }
    }
  }

  async function doSync() {
    if (!navigator.onLine) return
    setSyncing(true)
    const { synced, failed } = await syncAll()
    if (synced > 0) {
      setSyncMsg(`✅ ${synced} fiche(s) synchronisée(s)`)
      setUnsynced(getUnsyncedProspects().length)
      await loadData()
    } else if (failed > 0) {
      setSyncMsg(`⚠️ ${failed} erreur(s) de sync`)
    } else {
      setSyncMsg('✓ Tout est à jour')
    }
    setSyncing(false)
    setTimeout(() => setSyncMsg(''), 3000)
  }

  const statsByType = (Object.keys(ACTOR_LABELS) as ActorType[]).map((type) => ({
    type,
    label: ACTOR_LABELS[type],
    count: prospects.filter((p) => p.actor_type === type).length,
  }))

  const prioritaires = prospects.filter((p) => p.score_final >= 85).length

  return (
    <div className="max-w-md mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="text-center pt-4 pb-2">
        <div className="text-5xl mb-2">🌍</div>
        <h1 className="text-3xl font-bold text-brand-gold tracking-tight">
          Ferolink Street
        </h1>
        <p className="text-sm text-gray-400 mt-1">DORYLUS Africa — V0</p>

        {/* Indicateur réseau */}
        <div className={`
          inline-flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full mt-3
          ${online
            ? 'bg-emerald-900/50 text-emerald-400 border border-emerald-800'
            : 'bg-orange-900/50 text-orange-400 border border-orange-800'
          }
        `}>
          <span className={`w-2 h-2 rounded-full ${online ? 'bg-emerald-400' : 'bg-orange-400'}`} />
          {online ? 'En ligne' : 'Hors ligne — mode local'}
        </div>
      </div>

      {/* Message sync */}
      {syncMsg && (
        <div className="bg-emerald-900/30 border border-emerald-700 text-emerald-300 px-4 py-3 rounded-xl text-sm text-center">
          {syncMsg}
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-brand-green/20 border border-brand-green/40 rounded-2xl p-3 text-center">
          <div className="text-3xl font-bold text-cream">{prospects.length}</div>
          <div className="text-xs text-gray-400 mt-1">Total</div>
        </div>
        <div className={`rounded-2xl p-3 text-center border ${
          unsynced > 0
            ? 'bg-orange-900/30 border-orange-700'
            : 'bg-anthracite-800 border-anthracite-600'
        }`}>
          <div className={`text-3xl font-bold ${unsynced > 0 ? 'text-orange-400' : 'text-gray-400'}`}>
            {unsynced}
          </div>
          <div className="text-xs text-gray-400 mt-1">Hors-ligne</div>
        </div>
        <div className={`rounded-2xl p-3 text-center border ${
          prioritaires > 0
            ? 'bg-orange-900/30 border-orange-700'
            : 'bg-anthracite-800 border-anthracite-600'
        }`}>
          <div className={`text-3xl font-bold ${prioritaires > 0 ? 'text-brand-orange' : 'text-gray-400'}`}>
            {prioritaires}
          </div>
          <div className="text-xs text-gray-400 mt-1">🔥 Prio</div>
        </div>
      </div>

      {/* Stats par type */}
      {prospects.length > 0 && (
        <div className="bg-anthracite-800 border border-anthracite-600 rounded-2xl p-4 space-y-2">
          <h2 className="text-gray-400 text-xs uppercase tracking-widest mb-3">
            Par type d&apos;acteur
          </h2>
          {statsByType.filter((s) => s.count > 0).map((s) => (
            <div key={s.type} className="flex items-center justify-between">
              <span className="text-sm text-gray-300">{s.label}</span>
              <span className="bg-brand-green/20 text-brand-light font-bold text-sm px-3 py-0.5 rounded-full border border-brand-green/30">
                {s.count}
              </span>
            </div>
          ))}
          {statsByType.every((s) => s.count === 0) && (
            <p className="text-sm text-gray-500 text-center py-2">Aucune fiche encore</p>
          )}
        </div>
      )}

      {/* Actions principales */}
      <div className="space-y-3">
        <Link href="/nouvelle" className="block">
          <button className="w-full bg-brand-gold text-brand-dark font-bold text-xl py-5 rounded-2xl hover:opacity-90 active:scale-98 transition-all flex items-center justify-center gap-3">
            ➕ Nouvelle enquête
          </button>
        </Link>

        <Link href="/fiches" className="block">
          <button className="w-full bg-brand-green text-cream font-bold text-xl py-5 rounded-2xl hover:opacity-90 active:scale-98 transition-all flex items-center justify-center gap-3">
            📋 Voir les fiches
          </button>
        </Link>

        {unsynced > 0 && (
          <button
            onClick={doSync}
            disabled={syncing || !online}
            className="w-full bg-orange-600 text-white font-bold text-lg py-4 rounded-2xl hover:bg-orange-500 active:scale-98 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {syncing ? (
              <>
                <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Synchronisation…
              </>
            ) : (
              <>🔄 Synchroniser ({unsynced})</>
            )}
          </button>
        )}
      </div>

      {/* Footer */}
      <div className="text-center text-xs text-gray-600 pt-4 pb-8">
        Ferolink Street V0 · DORYLUS Africa
      </div>
    </div>
  )
}
