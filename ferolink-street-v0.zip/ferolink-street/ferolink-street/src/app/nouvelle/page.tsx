'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import ActorTypeSelector from '@/components/ActorTypeSelector'
import IdentityForm, { type IdentityData, defaultIdentity } from '@/components/IdentityForm'
import DynamicQuestionnaire from '@/components/DynamicQuestionnaire'
import Button from '@/components/Button'
import type { ActorType } from '@/lib/supabaseClient'
import type { Prospect } from '@/lib/supabaseClient'
import { generateLocalId } from '@/lib/localStore'
import { computeAutoScore, computeFinalScore, getScoreLabel } from '@/lib/scoring'
import { saveProspect } from '@/lib/sync'

type Step = 'type' | 'identite' | 'questionnaire'

const STEPS: Step[] = ['type', 'identite', 'questionnaire']
const STEP_LABELS = ['Type', 'Identité', 'Questions']

export default function NouvellePage() {
  const router = useRouter()
  const [step, setStep] = useState<Step>('type')
  const [actorType, setActorType] = useState<ActorType | null>(null)
  const [identity, setIdentity] = useState<IdentityData>(defaultIdentity)
  const [answers, setAnswers] = useState<Record<string, string | number>>({})
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState<{ offline: boolean; scoreInfo: ReturnType<typeof getScoreLabel>; score: number } | null>(null)

  const stepIndex = STEPS.indexOf(step)

  const canProceed = (): boolean => {
    if (step === 'type') return actorType !== null
    if (step === 'identite') {
      return (
        identity.full_name.trim().length > 0 &&
        identity.phone.trim().length > 0 &&
        identity.city.trim().length > 0
      )
    }
    return true
  }

  const next = () => {
    const idx = STEPS.indexOf(step)
    if (idx < STEPS.length - 1) setStep(STEPS[idx + 1])
  }

  const prev = () => {
    const idx = STEPS.indexOf(step)
    if (idx > 0) setStep(STEPS[idx - 1])
  }

  const handleSave = async () => {
    if (!actorType) return
    setSaving(true)

    const scoreAuto = computeAutoScore(actorType, answers)
    const scoreFinal = computeFinalScore(scoreAuto, null)
    const scoreInfo = getScoreLabel(scoreFinal)

    const prospect: Prospect = {
      local_id:           generateLocalId(),
      actor_type:         actorType,
      full_name:          identity.full_name.trim(),
      phone:              identity.phone.trim(),
      city:               identity.city.trim(),
      zone:               identity.zone.trim() || undefined,
      contact_channel:    identity.contact_channel || undefined,
      referred_by:        identity.referred_by.trim() || undefined,
      payment_preference: identity.payment_preference || undefined,
      answers,
      score_auto:         scoreAuto,
      score_manuel:       null,
      score_final:        scoreFinal,
      status:             scoreFinal >= 85 ? 'prioritaire' : 'nouveau',
      notes:              identity.notes.trim(),
      is_synced:          false,
    }

    const res = await saveProspect(prospect)
    setSaved({ offline: res.offline, scoreInfo, score: scoreFinal })
    setSaving(false)
  }

  const resetForm = () => {
    setStep('type')
    setActorType(null)
    setIdentity(defaultIdentity)
    setAnswers({})
    setSaved(null)
  }

  const previewScore = actorType ? computeAutoScore(actorType, answers) : 0
  const previewInfo = getScoreLabel(previewScore)

  // ─── ÉCRAN CONFIRMATION ─────────────────────────────────────────────────────
  if (saved) {
    return (
      <div className="max-w-md mx-auto px-4 py-8 space-y-6">
        <div className="text-center space-y-4 py-4">
          <div className="text-6xl">{saved.offline ? '📥' : '✅'}</div>
          <h2 className="text-2xl font-bold text-cream">
            {saved.offline ? 'Sauvegardé hors ligne' : 'Fiche enregistrée !'}
          </h2>
          <p className="text-gray-400">
            {saved.offline
              ? 'Sera synchronisée automatiquement au retour du réseau.'
              : 'Sauvegardée et synchronisée avec Supabase.'}
          </p>
        </div>

        {/* Résumé */}
        <div className="bg-anthracite-800 border border-anthracite-600 rounded-2xl p-4 space-y-3">
          <div className="flex justify-between">
            <span className="text-gray-400 text-sm">Nom</span>
            <span className="text-cream font-semibold text-sm">{identity.full_name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400 text-sm">Ville</span>
            <span className="text-cream text-sm">{identity.city}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400 text-sm">Score</span>
            <span className={`text-sm font-bold ${saved.scoreInfo.color}`}>
              {saved.scoreInfo.emoji} {saved.score}/100 — {saved.scoreInfo.label}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400 text-sm">Action</span>
            <span className="text-brand-gold text-sm">{saved.scoreInfo.action}</span>
          </div>
        </div>

        <div className="space-y-3">
          <button
            onClick={resetForm}
            className="w-full bg-brand-gold text-brand-dark font-bold py-4 rounded-2xl text-lg hover:opacity-90 active:scale-98 transition-all"
          >
            ➕ Nouvelle enquête
          </button>
          <button
            onClick={() => router.push('/fiches')}
            className="w-full bg-brand-green text-cream font-bold py-4 rounded-2xl text-lg hover:opacity-90 active:scale-98 transition-all"
          >
            📋 Voir les fiches
          </button>
          <button
            onClick={() => router.push('/')}
            className="w-full text-gray-400 py-3 text-base hover:text-gray-300"
          >
            🏠 Accueil
          </button>
        </div>
      </div>
    )
  }

  // ─── FORMULAIRE PRINCIPAL ────────────────────────────────────────────────────
  return (
    <div className="max-w-md mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={() => (stepIndex > 0 ? prev() : router.back())}
          className="text-2xl text-gray-400 hover:text-cream transition-colors"
        >
          ←
        </button>
        <div>
          <h1 className="text-xl font-bold text-brand-gold leading-tight">
            Ferolink Street
          </h1>
          <p className="text-xs text-gray-500">Nouvelle enquête terrain</p>
        </div>
      </div>

      {/* Stepper */}
      <div className="flex items-center gap-2 mb-8">
        {STEP_LABELS.map((label, i) => (
          <div key={i} className="flex items-center flex-1">
            <div className={`
              flex items-center justify-center w-8 h-8 rounded-full text-sm font-bold flex-shrink-0
              ${i < stepIndex
                ? 'bg-brand-gold text-brand-dark'
                : i === stepIndex
                ? 'bg-brand-green text-cream'
                : 'bg-anthracite-700 text-gray-500'
              }
            `}>
              {i < stepIndex ? '✓' : i + 1}
            </div>
            <span className={`ml-1.5 text-xs flex-1 ${i === stepIndex ? 'text-cream font-semibold' : 'text-gray-500'}`}>
              {label}
            </span>
            {i < STEP_LABELS.length - 1 && (
              <div className={`w-4 h-px mx-1 ${i < stepIndex ? 'bg-brand-gold' : 'bg-anthracite-600'}`} />
            )}
          </div>
        ))}
      </div>

      {/* Contenu */}
      <div className="space-y-6">
        {step === 'type' && (
          <ActorTypeSelector selected={actorType} onSelect={setActorType} />
        )}

        {step === 'identite' && (
          <IdentityForm data={identity} onChange={setIdentity} />
        )}

        {step === 'questionnaire' && actorType && (
          <>
            <DynamicQuestionnaire
              actorType={actorType}
              answers={answers}
              onChange={setAnswers}
            />

            {/* Preview score */}
            <div className={`
              rounded-2xl p-4 text-center border
              ${previewInfo.isPriority
                ? 'bg-orange-900/20 border-orange-700'
                : 'bg-anthracite-800 border-anthracite-600'
              }
            `}>
              <div className="text-xs text-gray-400 mb-1">Score estimé</div>
              <div className={`text-4xl font-bold ${previewInfo.color}`}>
                {previewInfo.emoji} {previewScore}
              </div>
              <div className="text-sm text-gray-400">/100 — {previewInfo.label}</div>
              <div className="text-xs text-brand-gold mt-1">{previewInfo.action}</div>
            </div>
          </>
        )}
      </div>

      {/* Boutons navigation */}
      <div className="flex gap-3 mt-8 pb-8">
        {stepIndex > 0 && (
          <Button variant="ghost" onClick={prev} className="flex-1">
            ← Retour
          </Button>
        )}

        {step !== 'questionnaire' ? (
          <Button
            variant="primary"
            onClick={next}
            disabled={!canProceed()}
            className="flex-1"
          >
            Suivant →
          </Button>
        ) : (
          <Button
            variant="secondary"
            onClick={handleSave}
            loading={saving}
            disabled={saving}
            className="flex-1"
          >
            💾 Sauvegarder
          </Button>
        )}
      </div>
    </div>
  )
}
