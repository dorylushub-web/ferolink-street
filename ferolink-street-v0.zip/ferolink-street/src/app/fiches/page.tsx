'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Prospect } from '@/lib/supabaseClient'
import { getAllLocal } from '@/lib/localStore'
import { fetchAllFromSupabase, syncPendingProspects } from '@/lib/sync'
import FicheCard from '@/components/FicheCard'
import FilterBar, { Filters } from '@/components/FilterBar'
import { ACTOR_LABELS, ActorType } from '@/lib/questionnaires'

export default function FichesPage() {
  const router = useRouter()
  const [prospects, setProspects] = useState<Prospect[]>([])
  const [loading, setLoading] = useState(true)
  const [syncing, setSyncing] = useState(false)
  const [filters, setFilters] = useState<Filters>({ actorType: '', city: '', status: '' })

  useEffect(() => {
    loadProspects()
    // Sync auto au chargement
    if (navigator.onLine) {
      doSync()
    }
  }, [])

  async function loadProspects() {
    setLoading(true)
    // D'abord local
    const local = getAllLocal()
    setProspects(local)

    // Puis Supabase si connecté
    if (navigator.onLine) {
      const remote = await fetchAllFromSupabase()
      if (remote.length > 0) setProspects(remote)
    }
    setLoading(false)
  }

  async function doSync() {
    setSyncing(true)
    await syncPendingProspects()
    await loadProspects()
    setSyncing(false)
  }

  // Villes uniques pour le filtre
  const cities = [...new Set(prospects.map(p => p.city).filter(Boolean))].sort()

  // Application des filtres
  const filtered = prospects.filter(p => {
    if (filters.actorType && p.actor_type !== filters.actorType) return false
    if (filters.city && p.city !== filters.city) return false
    if (filters.status && p.status !== filters.status) return false
    return true
  })

  // Export CSV
  const exportCSV = () => {
    const headers = [
      'ID', 'Type', 'Nom', 'Téléphone', 'Ville',
      'Score Auto', 'Score Manuel', 'Score Final',
      'Statut', 'Synchronisé', 'Notes', 'Réponses'
    ]

    const rows = filtered.map(p => [
      p.id || p.local_id,
      ACTOR_LABELS[p.actor_type as ActorType] || p.actor_type,
      p.full_name,
      p.phone,
      p.city,
      p.score_auto,
      p.score_manuel ?? '',
      p.score_final,
      p.status,
      p.is_synced ? 'Oui' : 'Non',
      p.notes || '',
      JSON.stringify(p.answers || {}),
    ])

    const csv = [headers, ...rows]
      .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n')

    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `ferolink_export_${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleUpdate = (updated: Prospect) => {
    setProspects(prev =>
      prev.map(p => p.local_id === updated.local_id ? updated : p)
    )
  }

  return (
    <div className="max-w-md mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <button onClick={() => router.back()} className="text-2xl">←</button>
        <h1 className="text-2xl font-display font-bold text-brand-green flex-1">
          Fiches terrain
        </h1>
        <span className="bg-brand-green text-white text-sm font-bold px-3 py-1 rounded-full">
          {filtered.length}
        </span>
      </div>

      {/* Actions */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={exportCSV}
          disabled={filtered.length === 0}
          className="flex-1 bg-brand-gold text-brand-dark font-semibold py-3 rounded-xl
            hover:bg-yellow-500 active:bg-yellow-600 transition-all
            disabled:opacity-40 disabled:cursor-not-allowed
            flex items-center justify-center gap-2 text-sm"
        >
          📥 Export CSV
        </button>
        <button
          onClick={doSync}
          disabled={syncing || !navigator.onLine}
          className="flex-1 bg-white text-brand-green font-semibold py-3 rounded-xl
            border-2 border-brand-green hover:bg-brand-light transition-all
            disabled:opacity-40 disabled:cursor-not-allowed
            flex items-center justify-center gap-2 text-sm"
        >
          {syncing
            ? <><span className="w-4 h-4 border-2 border-brand-green border-t-transparent rounded-full animate-spin" /> Sync...</>
            : '🔄 Synchroniser'
          }
        </button>
      </div>

      {/* Filtres */}
      <div className="mb-4">
        <FilterBar
          filters={filters}
          onChange={setFilters}
          cities={cities}
        />
      </div>

      {/* Liste */}
      {loading ? (
        <div className="text-center py-16">
          <div className="w-10 h-10 border-4 border-brand-green border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-500">Chargement...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 space-y-4">
          <div className="text-5xl">📋</div>
          <p className="text-gray-500 text-lg">
            {prospects.length === 0
              ? 'Aucune fiche pour l\'instant'
              : 'Aucune fiche ne correspond aux filtres'}
          </p>
          {prospects.length === 0 && (
            <button
              onClick={() => router.push('/nouvelle')}
              className="bg-brand-green text-white font-bold py-3 px-6 rounded-xl"
            >
              ➕ Créer la première fiche
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4 pb-8">
          {filtered.map(p => (
            <FicheCard
              key={p.local_id || p.id}
              prospect={p}
              onUpdate={handleUpdate}
            />
          ))}
        </div>
      )}
    </div>
  )
}
