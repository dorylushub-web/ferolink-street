import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Ferolink Street',
  description: 'Outil terrain DORYLUS Africa — collecte de données stratégiques',
  manifest: '/manifest.json',
  themeColor: '#1a4d2e',
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'FeroStreet',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#1a4d2e" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
      </head>
      <body className="bg-brand-cream min-h-screen font-body antialiased">
        {children}
      </body>
    </html>
  )
}
