'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import ActorTypeSelector from '@/components/ActorTypeSelector'
import IdentityForm from '@/components/IdentityForm'
import DynamicQuestionnaire from '@/components/DynamicQuestionnaire'
import Button from '@/components/Button'
import { ActorType } from '@/lib/questionnaires'
import { Prospect } from '@/lib/supabaseClient'
import { generateLocalId } from '@/lib/localStore'
import { computeAutoScore, computeFinalScore } from '@/lib/scoring'
import { saveProspect } from '@/lib/sync'

type Step = 'type' | 'identite' | 'questionnaire' | 'confirmation'

const STEPS = ['type', 'identite', 'questionnaire', 'confirmation']
const STEP_LABELS = ['Type', 'Identité', 'Questions', 'Résumé']

interface IdentityData {
  full_name: string
  phone: string
  city: string
  notes: string
}

export default function NouvellePage() {
  const router = useRouter()
  const [step, setStep] = useState<Step>('type')
  const [actorType, setActorType] = useState<ActorType | null>(null)
  const [identity, setIdentity] = useState<IdentityData>({
    full_name: '',
    phone: '',
    city: '',
    notes: '',
  })
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)
  const [result, setResult] = useState<{ offline: boolean } | null>(null)

  const stepIndex = STEPS.indexOf(step)

  // Validation par étape
  const canProceed = () => {
    if (step === 'type') return actorType !== null
    if (step === 'identite') return identity.full_name.trim() && identity.phone.trim() && identity.city.trim()
    if (step === 'questionnaire') return true
    return false
  }

  const next = () => {
    const idx = STEPS.indexOf(step)
    if (idx < STEPS.length - 1) setStep(STEPS[idx + 1] as Step)
  }

  const prev = () => {
    const idx = STEPS.indexOf(step)
    if (idx > 0) setStep(STEPS[idx - 1] as Step)
  }

  const handleSave = async () => {
    if (!actorType) return
    setSaving(true)

    const scoreAuto = computeAutoScore(actorType, answers)
    const scoreFinal = computeFinalScore(scoreAuto, null)

    const prospect: Prospect = {
      local_id: generateLocalId(),
      actor_type: actorType,
      full_name: identity.full_name.trim(),
      phone: identity.phone.trim(),
      city: identity.city.trim(),
      answers,
      score_auto: scoreAuto,
      score_manuel: null,
      score_final: scoreFinal,
      status: 'nouveau',
      notes: identity.notes.trim(),
      is_synced: false,
    }

    const res = await saveProspect(prospect)
    setResult({ offline: res.offline })
    setSaving(false)
    setStep('confirmation')
  }

  // Calcul preview score
  const previewScore = actorType ? computeAutoScore(actorType, answers) : 0

  return (
    <div className="max-w-md mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => router.back()} className="text-2xl">←</button>
        <h1 className="text-2xl font-display font-bold text-brand-green">
          Nouvelle enquête
        </h1>
      </div>

      {/* Stepper */}
      {step !== 'confirmation' && (
        <div className="flex items-center gap-1 mb-8">
          {STEP_LABELS.slice(0, 3).map((label, i) => (
            <div key={i} className="flex items-center flex-1">
              <div className={`
                flex items-center justify-center w-8 h-8 rounded-full text-sm font-bold
                ${i < stepIndex
                  ? 'bg-brand-gold text-white'
                  : i === stepIndex
                  ? 'bg-brand-green text-white'
                  : 'bg-gray-200 text-gray-400'
                }
              `}>
                {i < stepIndex ? '✓' : i + 1}
              </div>
              <span className={`ml-1 text-xs flex-1 ${i === stepIndex ? 'text-brand-green font-semibold' : 'text-gray-400'}`}>
                {label}
              </span>
              {i < 2 && <div className={`w-4 h-0.5 mx-1 ${i < stepIndex ? 'bg-brand-gold' : 'bg-gray-200'}`} />}
            </div>
          ))}
        </div>
      )}

      {/* Contenu par étape */}
      <div className="space-y-6">

        {step === 'type' && (
          <ActorTypeSelector
            selected={actorType}
            onSelect={setActorType}
          />
        )}

        {step === 'identite' && (
          <IdentityForm
            data={identity}
            onChange={setIdentity}
          />
        )}

        {step === 'questionnaire' && actorType && (
          <>
            <DynamicQuestionnaire
              actorType={actorType}
              answers={answers}
              onChange={setAnswers}
            />
            {/* Preview score */}
            <div className="bg-brand-light border border-brand-green/20 rounded-xl p-4 text-center">
              <div className="text-sm text-gray-600 mb-1">Score estimé</div>
              <div className="text-4xl font-bold text-brand-green">{previewScore}</div>
              <div className="text-sm text-gray-500">/100</div>
            </div>
          </>
        )}

        {/* Résumé + confirmation */}
        {step === 'questionnaire' && result === null && (
          <></>
        )}

        {step === 'confirmation' && result && (
          <div className="text-center space-y-6 py-8">
            <div className="text-6xl">{result.offline ? '📥' : '✅'}</div>
            <h2 className="text-2xl font-bold text-brand-green">
              {result.offline ? 'Sauvegardé hors ligne' : 'Fiche enregistrée !'}
            </h2>
            <p className="text-gray-600">
              {result.offline
                ? 'La fiche sera synchronisée automatiquement dès le retour du réseau.'
                : 'La fiche a été sauvegardée et synchronisée avec succès.'}
            </p>
            <div className="bg-white rounded-2xl border p-4 text-left space-y-2">
              <div><span className="font-semibold">Nom :</span> {identity.full_name}</div>
              <div><span className="font-semibold">Ville :</span> {identity.city}</div>
              <div><span className="font-semibold">Score :</span> {previewScore}/100</div>
            </div>
            <div className="space-y-3">
              <button
                onClick={() => {
                  setStep('type')
                  setActorType(null)
                  setIdentity({ full_name: '', phone: '', city: '', notes: '' })
                  setAnswers({})
                  setResult(null)
                }}
                className="w-full bg-brand-green text-white font-bold py-4 rounded-2xl text-lg"
              >
                ➕ Nouvelle enquête
              </button>
              <button
                onClick={() => router.push('/fiches')}
                className="w-full bg-white text-brand-green font-bold py-4 rounded-2xl text-lg border-2 border-brand-green"
              >
                📋 Voir les fiches
              </button>
              <button
                onClick={() => router.push('/')}
                className="w-full text-gray-500 py-3 text-base"
              >
                🏠 Accueil
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Boutons navigation (sauf confirmation) */}
      {step !== 'confirmation' && (
        <div className="flex gap-3 mt-8">
          {stepIndex > 0 && (
            <Button variant="ghost" onClick={prev} className="flex-1">
              ← Retour
            </Button>
          )}

          {step !== 'questionnaire' ? (
            <Button
              variant="primary"
              onClick={next}
              disabled={!canProceed()}
              className="flex-1"
            >
              Suivant →
            </Button>
          ) : (
            <Button
              variant="secondary"
              onClick={handleSave}
              loading={saving}
              disabled={saving}
              className="flex-1"
            >
              💾 Sauvegarder
            </Button>
          )}
        </div>
      )}
    </div>
  )
}
