'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Prospect } from '@/lib/supabaseClient'
import { getAllLocal, getUnsynced } from '@/lib/localStore'
import { syncPendingProspects, fetchAllFromSupabase } from '@/lib/sync'
import { ACTOR_LABELS, ActorType } from '@/lib/questionnaires'

export default function Dashboard() {
  const [prospects, setProspects] = useState<Prospect[]>([])
  const [unsynced, setUnsynced] = useState(0)
  const [syncing, setSyncing] = useState(false)
  const [syncMsg, setSyncMsg] = useState('')
  const [online, setOnline] = useState(true)

  useEffect(() => {
    // Détection réseau
    setOnline(navigator.onLine)
    const handleOnline = () => {
      setOnline(true)
      doSync()
    }
    const handleOffline = () => setOnline(false)
    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)

    // Chargement initial
    loadData()

    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
  }, [])

  async function loadData() {
    const local = getAllLocal()
    setProspects(local)
    setUnsynced(getUnsynced().length)

    // Essaie de charger depuis Supabase
    if (navigator.onLine) {
      const remote = await fetchAllFromSupabase()
      if (remote.length > 0) setProspects(remote)
    }
  }

  async function doSync() {
    setSyncing(true)
    const { synced, errors } = await syncPendingProspects()
    if (synced > 0) {
      setSyncMsg(`✅ ${synced} fiche(s) synchronisée(s)`)
      setUnsynced(getUnsynced().length)
      await loadData()
    } else if (errors > 0) {
      setSyncMsg(`⚠️ ${errors} erreur(s) de sync`)
    }
    setSyncing(false)
    setTimeout(() => setSyncMsg(''), 3000)
  }

  // Stats par type
  const statsByType = (Object.keys(ACTOR_LABELS) as ActorType[]).map(type => ({
    type,
    label: ACTOR_LABELS[type],
    count: prospects.filter(p => p.actor_type === type).length,
  }))

  return (
    <div className="max-w-md mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="text-center py-4">
        <div className="text-4xl mb-2">🌍</div>
        <h1 className="text-3xl font-display font-bold text-brand-green">
          Ferolink Street
        </h1>
        <p className="text-sm text-gray-500 mt-1">DORYLUS Africa — Outil Terrain</p>

        {/* Indicateur réseau */}
        <div className={`inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full mt-2 ${
          online ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
        }`}>
          <span className={`w-2 h-2 rounded-full ${online ? 'bg-green-500' : 'bg-orange-500'}`} />
          {online ? 'En ligne' : 'Hors ligne'}
        </div>
      </div>

      {/* Message sync */}
      {syncMsg && (
        <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-xl text-sm text-center">
          {syncMsg}
        </div>
      )}

      {/* Stats globales */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-brand-green text-white rounded-2xl p-4 text-center">
          <div className="text-4xl font-bold">{prospects.length}</div>
          <div className="text-sm opacity-80 mt-1">Fiches totales</div>
        </div>
        <div className={`rounded-2xl p-4 text-center ${
          unsynced > 0 ? 'bg-orange-100 text-orange-800' : 'bg-gray-100 text-gray-600'
        }`}>
          <div className="text-4xl font-bold">{unsynced}</div>
          <div className="text-sm opacity-80 mt-1">Non synchronisées</div>
        </div>
      </div>

      {/* Stats par type */}
      {prospects.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 p-4 space-y-2">
          <h2 className="font-semibold text-brand-dark text-sm uppercase tracking-wide mb-3">
            Par type d'acteur
          </h2>
          {statsByType.filter(s => s.count > 0).map(s => (
            <div key={s.type} className="flex items-center justify-between">
              <span className="text-sm text-gray-700">{s.label}</span>
              <span className="bg-brand-light text-brand-green font-bold text-sm px-3 py-1 rounded-full">
                {s.count}
              </span>
            </div>
          ))}
          {statsByType.every(s => s.count === 0) && (
            <p className="text-sm text-gray-400 text-center py-2">Aucune fiche encore</p>
          )}
        </div>
      )}

      {/* Actions principales */}
      <div className="space-y-3">
        <Link href="/nouvelle">
          <button className="w-full bg-brand-green text-white font-bold text-xl py-5 rounded-2xl
            hover:bg-green-800 active:bg-green-900 transition-all
            flex items-center justify-center gap-3">
            ➕ Nouvelle enquête
          </button>
        </Link>

        <Link href="/fiches">
          <button className="w-full bg-white text-brand-green font-bold text-xl py-5 rounded-2xl
            border-2 border-brand-green hover:bg-brand-light active:bg-green-100 transition-all
            flex items-center justify-center gap-3 mt-3">
            📋 Voir les fiches
          </button>
        </Link>

        {unsynced > 0 && (
          <button
            onClick={doSync}
            disabled={syncing || !online}
            className="w-full bg-brand-gold text-brand-dark font-bold text-lg py-4 rounded-2xl
              hover:bg-yellow-500 active:bg-yellow-600 transition-all
              disabled:opacity-50 disabled:cursor-not-allowed
              flex items-center justify-center gap-2"
          >
            {syncing ? (
              <>
                <span className="w-5 h-5 border-2 border-brand-dark border-t-transparent rounded-full animate-spin" />
                Synchronisation...
              </>
            ) : (
              <>🔄 Synchroniser ({unsynced})</>
            )}
          </button>
        )}
      </div>

      {/* Footer */}
      <div className="text-center text-xs text-gray-400 pt-4 pb-8">
        Version 0.1 — DORYLUS Africa
      </div>
    </div>
  )
}
