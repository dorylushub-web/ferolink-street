import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Type principal pour une fiche prospect
export interface Prospect {
  id?: string
  local_id: string
  actor_type: 'commercant' | 'producteur' | 'transporteur' | 'partenaire_local' | 'client_pro'
  full_name: string
  phone: string
  city: string
  answers: Record<string, string | number>
  score_auto: number
  score_manuel: number | null
  score_final: number
  status: 'nouveau' | 'contacte' | 'qualifie' | 'archive'
  notes: string
  is_synced: boolean
  created_at?: string
}
