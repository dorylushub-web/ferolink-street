import { QUESTIONNAIRES, ActorType } from './questionnaires'

// Calcule le score automatique (0-100) basé sur les réponses
export function computeAutoScore(
  actorType: ActorType,
  answers: Record<string, string>
): number {
  const questions = QUESTIONNAIRES[actorType]
  if (!questions || questions.length === 0) return 0

  let totalWeight = 0
  let earnedPoints = 0

  for (const q of questions) {
    totalWeight += q.weight
    const answer = answers[q.id]
    if (!answer) continue

    if (q.positiveValues && q.positiveValues.includes(answer)) {
      earnedPoints += q.weight
    }
  }

  if (totalWeight === 0) return 0
  return Math.round((earnedPoints / totalWeight) * 100)
}

// Calcule le score final : score_manuel s'il existe, sinon score_auto
export function computeFinalScore(
  scoreAuto: number,
  scoreManuel: number | null
): number {
  if (scoreManuel !== null && scoreManuel >= 0) return scoreManuel
  return scoreAuto
}

// Label et couleur selon le score
export type ScoreLevel = 'faible' | 'moyen' | 'fort'

export function getScoreLevel(score: number): ScoreLevel {
  if (score >= 70) return 'fort'
  if (score >= 40) return 'moyen'
  return 'faible'
}

export const SCORE_COLORS: Record<ScoreLevel, string> = {
  faible: 'bg-red-100 text-red-800 border-red-300',
  moyen:  'bg-yellow-100 text-yellow-800 border-yellow-300',
  fort:   'bg-green-100 text-green-800 border-green-300',
}

export const SCORE_ICONS: Record<ScoreLevel, string> = {
  faible: '🔴',
  moyen:  '🟡',
  fort:   '🟢',
}

export const SCORE_LABELS: Record<ScoreLevel, string> = {
  faible: 'Faible',
  moyen:  'Moyen',
  fort:   'Fort',
}
