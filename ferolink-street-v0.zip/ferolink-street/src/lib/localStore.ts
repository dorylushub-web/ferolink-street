import { Prospect } from './supabaseClient'

const STORAGE_KEY = 'ferolink_prospects'

// Génère un ID local unique
export function generateLocalId(): string {
  return `local_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
}

// Récupère toutes les fiches stockées localement
export function getAllLocal(): Prospect[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    return JSON.parse(raw) as Prospect[]
  } catch {
    return []
  }
}

// Sauvegarde ou met à jour une fiche localement
export function saveLocal(prospect: Prospect): void {
  if (typeof window === 'undefined') return
  try {
    const all = getAllLocal()
    const idx = all.findIndex(p => p.local_id === prospect.local_id)
    if (idx >= 0) {
      all[idx] = prospect
    } else {
      all.push(prospect)
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all))
  } catch (e) {
    console.error('Erreur localStorage:', e)
  }
}

// Marque une fiche comme synchronisée (met à jour local + id Supabase)
export function markSynced(localId: string, supabaseId: string): void {
  if (typeof window === 'undefined') return
  try {
    const all = getAllLocal()
    const idx = all.findIndex(p => p.local_id === localId)
    if (idx >= 0) {
      all[idx].is_synced = true
      all[idx].id = supabaseId
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all))
  } catch (e) {
    console.error('Erreur markSynced:', e)
  }
}

// Supprime une fiche locale
export function deleteLocal(localId: string): void {
  if (typeof window === 'undefined') return
  try {
    const all = getAllLocal().filter(p => p.local_id !== localId)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all))
  } catch (e) {
    console.error('Erreur deleteLocal:', e)
  }
}

// Retourne uniquement les fiches non synchronisées
export function getUnsynced(): Prospect[] {
  return getAllLocal().filter(p => !p.is_synced)
}
