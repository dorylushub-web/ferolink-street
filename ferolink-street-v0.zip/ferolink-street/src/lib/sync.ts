import { supabase, Prospect } from './supabaseClient'
import { getUnsynced, markSynced, saveLocal } from './localStore'

// Synchronise toutes les fiches locales non synchronisées vers Supabase
export async function syncPendingProspects(): Promise<{ synced: number; errors: number }> {
  const pending = getUnsynced()
  if (pending.length === 0) return { synced: 0, errors: 0 }

  let synced = 0
  let errors = 0

  for (const prospect of pending) {
    try {
      // On enlève id pour laisser Supabase générer un UUID
      const { local_id, id, ...dataToInsert } = prospect
      const payload = { ...dataToInsert, local_id }

      const { data, error } = await supabase
        .from('prospects')
        .insert(payload)
        .select('id')
        .single()

      if (error) {
        console.error(`Erreur sync ${local_id}:`, error)
        errors++
      } else if (data) {
        markSynced(local_id, data.id)
        synced++
      }
    } catch (e) {
      console.error('Erreur réseau sync:', e)
      errors++
    }
  }

  return { synced, errors }
}

// Charge toutes les fiches depuis Supabase
export async function fetchAllFromSupabase(): Promise<Prospect[]> {
  const { data, error } = await supabase
    .from('prospects')
    .select('*')
    .order('created_at', { ascending: false })

  if (error) {
    console.error('Erreur fetch Supabase:', error)
    return []
  }
  return (data as Prospect[]) || []
}

// Sauvegarde une fiche : essaie Supabase, sinon local
export async function saveProspect(prospect: Prospect): Promise<{ success: boolean; offline: boolean }> {
  try {
    const { local_id, id, ...dataToInsert } = prospect
    const payload = { ...dataToInsert, local_id }

    const { data, error } = await supabase
      .from('prospects')
      .insert(payload)
      .select('id')
      .single()

    if (error) throw error

    // Sauvegarde aussi en local avec is_synced=true
    const synced: Prospect = { ...prospect, id: data.id, is_synced: true }
    saveLocal(synced)

    return { success: true, offline: false }
  } catch {
    // Réseau indisponible → sauvegarde offline
    const offline: Prospect = { ...prospect, is_synced: false }
    saveLocal(offline)
    return { success: true, offline: true }
  }
}

// Met à jour le score manuel dans Supabase et en local
export async function updateScoreManuel(
  prospect: Prospect,
  scoreManuel: number,
  scoreFinal: number
): Promise<boolean> {
  // Mise à jour locale immédiate
  const updated = { ...prospect, score_manuel: scoreManuel, score_final: scoreFinal }
  saveLocal(updated)

  // Si synchronisé, met à jour dans Supabase
  if (prospect.is_synced && prospect.id) {
    const { error } = await supabase
      .from('prospects')
      .update({ score_manuel: scoreManuel, score_final: scoreFinal })
      .eq('id', prospect.id)

    if (error) {
      console.error('Erreur update score:', error)
      return false
    }
  }
  return true
}
