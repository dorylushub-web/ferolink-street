// Questionnaires dynamiques par type d'acteur
// Chaque question a un id, un label, un type et un poids pour le scoring

export type QuestionType = 'select' | 'text' | 'number' | 'yesno'

export interface Question {
  id: string
  label: string
  type: QuestionType
  options?: string[]   // Pour les select
  weight: number       // Poids pour le calcul du score (0-10)
  positiveValues?: string[] // Valeurs qui donnent des points
}

export type ActorType = 'commercant' | 'producteur' | 'transporteur' | 'partenaire' | 'client_pro'

export const ACTOR_LABELS: Record<ActorType, string> = {
  commercant:    '🛍️ Commerçant',
  producteur:    '🌾 Producteur',
  transporteur:  '🚛 Transporteur',
  partenaire:    '🤝 Partenaire Local',
  client_pro:    '💼 Client Professionnel',
}

export const QUESTIONNAIRES: Record<ActorType, Question[]> = {

  commercant: [
    {
      id: 'activite',
      label: 'Type d\'activité principale',
      type: 'select',
      options: ['Alimentation', 'Textile', 'Électronique', 'Matériaux', 'Autre'],
      weight: 5,
      positiveValues: ['Alimentation', 'Matériaux'],
    },
    {
      id: 'volume_mensuel',
      label: 'Volume de marchandises par mois (estimation)',
      type: 'select',
      options: ['Moins de 100 kg', '100–500 kg', '500 kg–2 tonnes', 'Plus de 2 tonnes'],
      weight: 8,
      positiveValues: ['500 kg–2 tonnes', 'Plus de 2 tonnes'],
    },
    {
      id: 'fournisseur_actuel',
      label: 'A-t-il un fournisseur fixe ?',
      type: 'yesno',
      weight: 6,
      positiveValues: ['Non'],
    },
    {
      id: 'besoin_livraison',
      label: 'Besoin de livraison régulière ?',
      type: 'yesno',
      weight: 9,
      positiveValues: ['Oui'],
    },
    {
      id: 'zone_couverture',
      label: 'Zone de vente',
      type: 'select',
      options: ['Local (quartier)', 'Ville', 'Région', 'National'],
      weight: 7,
      positiveValues: ['Région', 'National'],
    },
  ],

  producteur: [
    {
      id: 'type_production',
      label: 'Type de production',
      type: 'select',
      options: ['Céréales', 'Légumes', 'Fruits', 'Élevage', 'Transformation', 'Autre'],
      weight: 5,
      positiveValues: ['Céréales', 'Transformation'],
    },
    {
      id: 'superficie',
      label: 'Superficie exploitée',
      type: 'select',
      options: ['Moins de 1 ha', '1–5 ha', '5–20 ha', 'Plus de 20 ha'],
      weight: 8,
      positiveValues: ['5–20 ha', 'Plus de 20 ha'],
    },
    {
      id: 'acces_route',
      label: 'Accès route carrossable ?',
      type: 'yesno',
      weight: 9,
      positiveValues: ['Oui'],
    },
    {
      id: 'stockage',
      label: 'Dispose d\'un lieu de stockage ?',
      type: 'yesno',
      weight: 7,
      positiveValues: ['Oui'],
    },
    {
      id: 'besoin_transport',
      label: 'Besoin de transport pour écouler sa production ?',
      type: 'yesno',
      weight: 10,
      positiveValues: ['Oui'],
    },
  ],

  transporteur: [
    {
      id: 'type_vehicule',
      label: 'Type de véhicule',
      type: 'select',
      options: ['Moto', 'Camionnette', 'Camion 5T', 'Camion 10T+', 'Autre'],
      weight: 8,
      positiveValues: ['Camion 5T', 'Camion 10T+'],
    },
    {
      id: 'nb_vehicules',
      label: 'Nombre de véhicules',
      type: 'select',
      options: ['1', '2–3', '4–10', 'Plus de 10'],
      weight: 9,
      positiveValues: ['4–10', 'Plus de 10'],
    },
    {
      id: 'zones_couvertes',
      label: 'Zones couvertes',
      type: 'select',
      options: ['Local', 'Régional', 'National', 'International'],
      weight: 7,
      positiveValues: ['National', 'International'],
    },
    {
      id: 'disponibilite',
      label: 'Disponibilité ?',
      type: 'select',
      options: ['Occasionnel', 'Temps partiel', 'Temps plein'],
      weight: 8,
      positiveValues: ['Temps plein'],
    },
    {
      id: 'partenariat',
      label: 'Ouvert à un partenariat logistique ?',
      type: 'yesno',
      weight: 10,
      positiveValues: ['Oui'],
    },
  ],

  partenaire: [
    {
      id: 'type_organisation',
      label: 'Type d\'organisation',
      type: 'select',
      options: ['ONG', 'Coopérative', 'Association', 'Mairie', 'Entreprise', 'Autre'],
      weight: 6,
      positiveValues: ['Coopérative', 'Entreprise'],
    },
    {
      id: 'zone_influence',
      label: 'Zone d\'influence',
      type: 'select',
      options: ['Village', 'Commune', 'Département', 'Région', 'National'],
      weight: 8,
      positiveValues: ['Département', 'Région', 'National'],
    },
    {
      id: 'reseau_membres',
      label: 'Nombre de membres / bénéficiaires',
      type: 'select',
      options: ['Moins de 50', '50–200', '200–1000', 'Plus de 1000'],
      weight: 7,
      positiveValues: ['200–1000', 'Plus de 1000'],
    },
    {
      id: 'collaboration_anterieure',
      label: 'Déjà collaboré avec un projet similaire ?',
      type: 'yesno',
      weight: 6,
      positiveValues: ['Oui'],
    },
    {
      id: 'capacite_mobilisation',
      label: 'Peut mobiliser des acteurs locaux ?',
      type: 'yesno',
      weight: 10,
      positiveValues: ['Oui'],
    },
  ],

  client_pro: [
    {
      id: 'secteur',
      label: 'Secteur d\'activité',
      type: 'select',
      options: ['Industrie', 'Commerce de gros', 'Distribution', 'Export', 'Services', 'Autre'],
      weight: 6,
      positiveValues: ['Commerce de gros', 'Distribution', 'Export'],
    },
    {
      id: 'volume_commande',
      label: 'Volume moyen de commande mensuel',
      type: 'select',
      options: ['Moins de 500 kg', '500 kg–2T', '2T–10T', 'Plus de 10T'],
      weight: 10,
      positiveValues: ['2T–10T', 'Plus de 10T'],
    },
    {
      id: 'frequence_commande',
      label: 'Fréquence de commande',
      type: 'select',
      options: ['Ponctuel', 'Mensuel', 'Hebdomadaire', 'Quotidien'],
      weight: 9,
      positiveValues: ['Hebdomadaire', 'Quotidien'],
    },
    {
      id: 'fournisseur_actuel',
      label: 'Satisfait de son fournisseur actuel ?',
      type: 'yesno',
      weight: 8,
      positiveValues: ['Non'],
    },
    {
      id: 'budget_transport',
      label: 'Budget transport dédié ?',
      type: 'yesno',
      weight: 7,
      positiveValues: ['Oui'],
    },
  ],
}
